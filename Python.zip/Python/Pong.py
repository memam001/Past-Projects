# Project Pong

import turtle
import winsound

wn = turtle.Screen()
wn.title("Pong")
wn.bgcolor("white")
wn.setup(width=800, height=600)
wn.tracer(0)
# scores
score_1=0
score_2=0

# eeh elakalam
kalam = turtle.Turtle()
kalam.speed(0)
kalam.color("black")
kalam.penup()
kalam.hideturtle()
kalam.goto(0, 260)
kalam.write("Player 1:0            Player 2:0   ".format(score_1, score_2) , align="center", font=("Times New Roman", 18, "normal"))

kalam2 = turtle.Turtle()
kalam2.speed(0)
kalam2.color("black")
kalam2.penup()
kalam2.hideturtle()
kalam2.goto(0, 0)

# elmadrab
madrab_1=turtle.Turtle()
madrab_1.speed(0)
madrab_1.shape("square")
madrab_1.color("black")
madrab_1.shapesize(stretch_len=1, stretch_wid=5)
madrab_1.penup()
madrab_1.goto(-350,0)

# elmadrab 2
madrab_2=turtle.Turtle()
madrab_2.speed(0)
madrab_2.shape("square")
madrab_2.color("black")
madrab_2.shapesize(stretch_len=1, stretch_wid=5)
madrab_2.penup()
madrab_2.goto(350,0)

# elkoora
koora=turtle.Turtle()
koora.speed(0)
koora.shape("circle")
koora.color("black")
koora.penup()
koora.goto(0,0)
koora.dx = .12
koora.dy = .12


# 
def madrab_1_etla3():
    y=madrab_1.ycor()
    y+=20
    madrab_1.sety(y)

def madrab_1_enzel():
    y=madrab_1.ycor()
    y-=20
    madrab_1.sety(y)

def madrab_2_etla3():
    y=madrab_2.ycor()
    y+=20
    madrab_2.sety(y)

def madrab_2_enzel():
    y=madrab_2.ycor()
    y-=20
    madrab_2.sety(y)


    score1=0
    score2=0
#
wn.listen()
wn.onkeypress(madrab_1_etla3, "w")
wn.onkeypress(madrab_1_enzel, "s")
wn.onkeypress(madrab_2_etla3, "Up")
wn.onkeypress(madrab_2_enzel, "Down")

#loop

while True:
    wn.update()

    koora.setx(koora.xcor() + koora.dx)
    koora.sety(koora.ycor() + koora.dy)


    if koora.ycor() > 290:
        koora.sety (290)
        koora.dy *= -1
        winsound.PlaySound(".wav", winsound.SND_ASYNC)

    if koora.ycor() < -290:
        koora.sety(-290)
        koora.dy *= -1
        winsound.PlaySound(".wav", winsound.SND_ASYNC)

    if koora.xcor() > 390:
        koora.goto(0,0)
        koora.dx *= -1
        score_1+=1
        kalam.clear()
        kalam.write("Player 1:{}            Player 2:{}   ".format(score_1, score_2), align="center",
                font=("Times New Roman", 18, "normal"))
        winsound.PlaySound("Fetty Wap - 679 feat Remy Boyz (Beau Di Angelo Remix).mp3", winsound.SND_ASYNC)
        kalam2.clear()
        kalam2.write("Congrats", align="center",
                     font=("Times New Roman", 24, "normal"))

    if koora.xcor() < -390:
        koora.goto(0,0)
        koora.dx *= -1
        score_2+=1
        kalam.clear()
        kalam.write("Player 1:{}            Player 2:{}   ".format(score_1, score_2), align="center",
                    font=("Times New Roman", 18, "normal"))
        winsound.PlaySound("Fetty Wap - 679 feat Remy Boyz (Beau Di Angelo Remix).mp3", winsound.SND_ASYNC)
        kalam2.clear()
        kalam2.write("Congrats", align="center",
                     font=("Times New Roman", 24, "normal"))




    if (koora.xcor() > 340 and koora.xcor() < 350  and (koora.ycor() < madrab_2.ycor() + 40 and koora.ycor() > madrab_2.ycor() - 40)):
        koora.setx(340)
        koora.dx *= -1
        winsound.PlaySound(".wav", winsound.SND_ASYNC)

    if (koora.xcor() > -350 and koora.xcor() < -340  and (koora.ycor() < madrab_1.ycor() + 40 and koora.ycor() > madrab_1.ycor() - 40)):
        koora.setx(-340)
        koora.dx *= -1
        winsound.PlaySound(".wav", winsound.SND_ASYNC)

