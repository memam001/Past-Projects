import Prog1Tools.Screen;
import Prog1Tools.TextScreen;

public class BallDemo{
	Ball Ball1=New Ball(0,0)
	public static void main(String[] args){
		TextScreen screen = TextScreen.getInstance();
		screen.setTitle("Jumping Balls Procedural");
		 for(step=1; step<=numberOfStepsToTake; step =step+1)
        {

           screen.write(row, column, BALL);
                   
           Screen.pause(PAUSE_TIME);
        }
    }
	}
}
