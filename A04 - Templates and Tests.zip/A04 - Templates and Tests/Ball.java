
public class Ball{
	private int row;
	private int column;
	private boolean rowDescending;
	private boolean columnDescending;

	public Ball(){
		row =0;
		column= 0;
		rowDescending = true;
		columnDescending = true;
	}
	public Ball(int row, int column){
		this.row =row;
		this.column= column;
		rowDescending = true;
		columnDescending = true;
	}
	public void setRow(int y){
		if(y > 0 && y < 24) {
			row = y;
		}
		
		
	}

	public void setColumn(int x){
		if(x > 0 && x < 79) {
			column = x;
		}
		
	}
	
	public int getRow(){
		return row;
	}
	
	public int getColumn(){
		return column;
	}

	public void calculateNewPosition(){
		if(column==79){
			columnDescending=false;
			}
       else if(column==0){
       	columnDescending=true;
       }
		
		if(row==24){
			rowDescending = false;} 
       else if(row==0){
       	rowDescending = true;
       	}
		
		if(columnDescending){
			column = column+1;
			}
    	else{
    		column = column-1;
    	}
    	if(rowDescending){
    		row=row+1;
    	}

    	else{
    		row = row-1;
    	}
	}






	
}
