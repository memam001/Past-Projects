
public class MyComplexNumber {
	private double real;
	private double imag;

	public MyComplexNumber(double real, double imag){
		this.real=real;
		this.imag=imag;
		
	}
	
	public double getReal(){
		return real;
	}
	public double getImag(){
		return imag;
	}
	public void add(MyComplexNumber x){
		
		double real, imag;
		real=x.getReal();
		imag=x.getImag();
		this.real=this.real+ real;
		this.imag=this.imag+imag;
	}
	public void subtract(MyComplexNumber x){
		
		double real, imag;
		real=x.getReal();
		imag=x.getImag();
		this.real=this.real- real;
		this.imag=this.imag-imag;
	}
	public void multiply(MyComplexNumber x){
		
		double real, imag;
		real=x.getReal();
		imag=x.getImag();
		this.real=(this.real*real-this.imag*imag);
		this.imag=(this.real*imag+this.imag*real);
	}
	public void divide(MyComplexNumber x){
		double real, imag;
		real=x.getReal();
		imag=x.getImag();
		double a;
		a=real*real-imag*imag;
		this.real=(this.real*real+this.imag*imag)/a;
		this.imag=(this.imag-this.real)/a;
	}
	
	public double magnitude(){
		return Math.sqrt(this.real*this.real+this.imag*this.imag);
}
}
