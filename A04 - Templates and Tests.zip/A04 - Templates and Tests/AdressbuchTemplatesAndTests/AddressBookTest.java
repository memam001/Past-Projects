import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class AddressBookTest
{	
	public static AddressBook myBook;
    String newName1, newName2;
	int newAge1,newAge2;
	String newAddress1, newAddress2;
	Friend myFriend1, myFriedn2;
	
	@Before
	public void createAddressBook(){
		myBook = new AddressBook(4);
		newName1 = "Lara" + ((int)(Math.random()*91)+10);
		newName2 = "Lara" + ((int)(Math.random()*91)+10);
		newAge1 = ((int)(Math.random()*90)+5);
		newAge2 = ((int)(Math.random()*90)+5);
		newAddress1 = "Bellinger Weg " + ((int)(Math.random()*90)+1);
		newAddress2 = "Bellinger Weg " + ((int)(Math.random()*90)+1);
        myBook.addFriend(newName1, newAge1, newAddress1);
        myBook.addFriend(newName2, newAge2, newAddress2);
	}

	private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();

	@Test
	public void testOutputOfAdressbook(){
		String outputString = "";
		try{
			System.setOut(new PrintStream(fromConsole));
			myBook.printAddressBook();
			
			outputString  = fromConsole.toString();

			

    	}catch(Exception e){System.err.println("Could not setup Streams");}

    	assertTrue("could not find age of first friend in printAddressBook()", 
    			outputString.contains(""+newAge1));
		assertTrue("could not find address of first friend in printAddressBook()", 
				outputString.contains(newAddress1));
		assertTrue("could not find name of first friend in printAddressBook()", 
				outputString.contains(newName1));
		assertTrue("could not find age of second friend in printAddressBook()", 
				outputString.contains(""+newAge2));
		assertTrue("could not find address of second friend in printAddressBook()", 
				outputString.contains(newAddress2));
		assertTrue("could not find name of second friend in printAddressBook()", 
				outputString.contains(newName2));
	}

	@Test
	public void testChangeAge(){
		String outputString = "";
		int newSetAge = -8;
		try{
			System.setOut(new PrintStream(fromConsole));
			
			newSetAge = newAge2/2+ ((int)(Math.random()*30)+5);
			myBook.changeAge(newName2, newAddress2, newSetAge);
			
			myBook.printAddressBook();
			
			outputString  = fromConsole.toString();

			

    	}catch(Exception e){System.err.println("Could not setup Streams");}

    	assertTrue("could not find age of first friend in printAddressBook()", 
    			outputString.contains(""+newSetAge));
	}
}
