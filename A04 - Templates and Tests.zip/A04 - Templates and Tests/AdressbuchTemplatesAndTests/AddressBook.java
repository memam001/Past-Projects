/**
 * Addressbook which holds the entries 
 * @author Larissa
 *
 */
public class AddressBook {
    private Friend[] myFriends;
    //actualPosition describes the amount of entries that have been consumed.
    private int actualPosition;
    private int numberOfEntries;

    /**
     * constructor. Initialize the global variables above
     * 
     * @param numberOfEntrys
     *            number of entries the book can have
     */
    public AddressBook(int numberOfEntries) {
        this.numberOfEntries=numberOfEntries;
        myFriends= new Friend[numberOfEntries];
        actualPosition = 0;

       
    }

    /**
     * Adds a friend if the address book isn't full already. 
     * 1. check if there are free entries 
     * 2. create a new friend with the given parameters 
     * 3. add it to myFriends 
     * 4. update data and return
     * 
     * @param name
     *            name of the friend
     * @param age
     *            age of the friend
     * @param address
     *            address of the friend
     * @return true if successful, false otherwise
     *///
     //i = 0, i=1, i=2, i=3, i =4, 
    public boolean addFriend(String name, int age, String address) {
        boolean result = false;
        int i=0 ;
        
		while(i<myFriends.length && myFriends[i]!= null){
        	i=i+1;
        }
        
        if(i<myFriends.length){
        	myFriends[i]=new Friend(name, age, address);
        	result = true;
        	actualPosition=i+1;
        }
        return result;
       
        
       
        //return result;
    }

    /**
     * your friend got older? change his age here. 
     * 1. look for the friend with the given name and address within the existing entries 
     *    (use the getAddress() and getName()-method of Friend. You can compare Strings with
     *    the equals(String toCompare)-method.
     * 2. if you found the friend, set the age to the given newAge 
     *    (use the setAge(int newAge)-method of Friend)
     * 3. return
     * 
     * @param name
     *            name of the friend
     * @param address
     *            address of the friend
     * @return true if successful, false otherwise
     */
 
    public boolean changeAge(String name, String address, int newAge) {
        boolean result = false;
        int i = 0;
        while(i<actualPosition && (!myFriends[i].getAddress().equals(address)||!myFriends[i].getName().equals(name))){
        i=i+1;
        }
        if(i<actualPosition){
        	myFriends[i].setAge(newAge);
        result=true;
        }
       
        return result;
    }

    /**
     * prints the field myFriends to the console
     */
    public void printAddressBook() {
        for (int i = 0; i < actualPosition; i++) {
            myFriends[i].printFriend();
        }
    }
}
