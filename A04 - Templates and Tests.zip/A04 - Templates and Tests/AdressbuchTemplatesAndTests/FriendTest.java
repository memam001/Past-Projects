import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class FriendTest
{	
	@Test
	public void testGetName(){
		String newName = "Lara" + ((int)(Math.random()*91)+10);
		int newAge = ((int)(Math.random()*90)+5);
		Friend myFriend = new Friend(newName, newAge, "Bellinger Weg 15");

		String returnedName = myFriend.getName();
		String errorMessage = "Tried to create new Object Friend with name: " + newName + System.lineSeparator() +
							  "Called getName() to get same, but returned name was: " + returnedName;
		assertTrue(errorMessage, newName.equals(returnedName));
	}

	@Test
	public void testGetAge(){
		String newName = "Lara" + ((int)(Math.random()*91)+10);
		int newAge = ((int)(Math.random()*90)+5);
		Friend myFriend = new Friend(newName, newAge, "Bellinger Weg 15");

		int returnedAge = myFriend.getAge();
		String errorMessage = "Tried to create new Object Friend with age: " + newAge + System.lineSeparator() +
							  "Called getAge() to get same, but returned name was: " + returnedAge;
		assertTrue(errorMessage, newAge == returnedAge);
	}

	@Test
	public void testGetAddress(){
		String newName = "Lara" + ((int)(Math.random()*91)+10);
		int newAge = ((int)(Math.random()*90)+5);
		String newAddress = "Bellinger Weg " + ((int)(Math.random()*90)+1);
		Friend myFriend = new Friend(newName, newAge, newAddress);

		String returnedAddress = myFriend.getAddress();
		String errorMessage = "Tried to create new Object Friend with age: " + newAddress + System.lineSeparator() +
							  "Called getAddress() to get same, but returned name was: " + returnedAddress;
		assertTrue(errorMessage, returnedAddress.equals(newAddress));
	}

	@Test
	public void testSetAge(){
		String newName = "Lara" + ((int)(Math.random()*91)+10);
		int newAge = ((int)(Math.random()*90)+5);
		Friend myFriend = new Friend(newName, newAge, "Bellinger Weg 15");

		int newSetAge = newAge/2+ ((int)(Math.random()*30)+5);

		myFriend.setAge(newSetAge);
		int returnedAge = myFriend.getAge();
		String errorMessage = "Tried create new Object Friend and setAge() to: " + newSetAge + System.lineSeparator() +
							  "Called getAge() to get same, but returned name was: " + returnedAge;
		assertTrue(errorMessage, newSetAge == returnedAge);
	}

	private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();
	
	@Test
	public void runMainMethod(){

		String newName = "Lara" + ((int)(Math.random()*91)+10);
		int newAge = ((int)(Math.random()*90)+5);
		String newAddress = "Bellinger Weg " + ((int)(Math.random()*90)+1);
		Friend myFriend = new Friend(newName, newAge, newAddress);

		String outputString = "";
		try{
			System.setOut(new PrintStream(fromConsole));
			myFriend.printFriend();
			
			outputString  = fromConsole.toString();

    	}catch(Exception e){System.err.println("Could not setup Streams");}

    	assertTrue("could not find age in print out of printFriend()", outputString.contains(""+newAge));
		assertTrue("could not find address in print out of printFriend()", outputString.contains(newAddress));
		assertTrue("could not find name in print out of printFriend()", outputString.contains(newName));
	}
}
