import Prog1Tools.IOTools;

public class CubeCalculations {
	public static void main(String[] args) {
		System.out.println("Welcome to the cube calculation program. ");
		double x;
		x = IOTools.readInt("Please input your desired cube spec: ");
		double v;
		v = (x*x*x)/(1000000);

		String temp = Double.toString(v);
		System.out.println(temp);
		System.out.println("The volume of your cube will be: " );
		System.out.format("%.3f",v);
		System.out.print("m^3");
		double y;
		y = IOTools.readInt("Please choose a material for your cube by typing the number assigned to it              1.plastic - 2.wood - 3.Iron: ");


		String message;
		 
		if (y == 1){message = "You have chosen plastic as your material";}
		else if (y == 2){message = "You have chosen wood as your material";}
		else if (y == 3){message = "You have chosen Iron as your material";}
		else {message = "The number you have chosen is not included. Please restart the program";}
		System.out.println(message);
		
		
		double p;
		
		if (y == 1){p=5;}
		else if (y == 2){p=15;}
		else if (y == 3){p=25;}
		else {p=10000;}
		System.out.println("density of your cube will be: ");
		System.out.format("%.3f", p);
		System.out.print("kg/m^3");
		
		double m;
		
		m=v*p;
		 
		System.out.println("The weight of your cube will be: ");
		System.out.format("%.3f", m);
		System.out.print("kg");
		
		
		double F;
		double g=9.81;
		double k=1;
		
		F=m*g*k;
		
		System.out.print("The force necessary to get your cube moving on the ground will be: ");
		System.out.format("%.3f", F);
		System.out.print("N");
		
		
		
		
		
	
	}
}
