public class BubbleSort{
	public static int[] randomSequence;
	
	//without side effects

	public static int[] generateNewRandomArray(int x){
		int[] randArray = new int[x];
		for(int i=0; i<x; i++){
			randArray[i]= (int)(Math.random()*1000);
		}
		return randArray;
	}

	public static void printArrayToConsole(int[] x){
		for(int i= 0;i<x.length;i++){
		System.out.print(x[i] + ", ");
		}
		System.out.println();
	}

	public static int[] sortArray(int[] a){
		
		int n = a.length-1;
		boolean somethingChanged ;
		int[] result = new int[a.length];
		
		for(int i=0;i<a.length;i++){
			result[i] = a[i];
		}
		
		do{
			somethingChanged = false;
			for(int i=0; i<n ;i++){
				if(result[i] > result[i+1]){
				// exchange values
				int temp = result[i];
				result[i] = result[i+1];
				result[i+1] = temp;
				somethingChanged = true;
				}
			}
			n = n - 1;
		}
		while(somethingChanged && n>=1);
	
	return result;
	}

	public static void main (String[] args){
		randomSequence = generateNewRandomArray(5);
		printArrayToConsole(randomSequence);
		int[] sortedSequence = sortArray(randomSequence);
		printArrayToConsole(sortedSequence);
		

		
	}

	
}
