
public class MyComplexNumber {
	private double real;
	private double imag;

	public MyComplexNumber(double real, double imag){
		this.real=real;
		this.imag=imag;
		
	}
	
	public double getReal(){
		return real;
	}
	public double getImag(){
		return imag;
	}
	public MyComplexNumber add(MyComplexNumber x){
		double real1 = x.getReal();
		double imag1 = x.getImag();
		double real2;
		double imag2;
		real1=x.getReal();
		imag1=x.getImag();
		real2=real+ real1;
		imag2=imag+imag1;
		return new MyComplexNumber(real2,imag2);
	}
	public MyComplexNumber subtract(MyComplexNumber x){
		double real1 = x.getReal();
		double imag1 = x.getImag();
		double real2;
		double imag2;
	

		real2=real- real1;
		imag2=imag-imag1;
		return new MyComplexNumber(real2,imag2);
	}
	public MyComplexNumber multiply(MyComplexNumber x){
		double real1 = x.getReal();
		double imag1 = x.getImag();
		double real2;
		double imag2;
		real2=(real*real1-imag*imag1);
		imag2=(real*imag1+imag*real1);
		return new MyComplexNumber(real2,imag2);
	}
	public MyComplexNumber divide(MyComplexNumber x){
		double real1 = x.getReal();
		double imag1 = x.getImag();
		double real2;
		double imag2; 
		double a;
		a=(real1*real1)+(imag1*imag1);
		real2=((real*real1)+(imag*imag1))/a;
		imag2=((imag*real1)-(real*imag1))/a;
		return new MyComplexNumber(real2,imag2);
	}
	
	public double magnitude(){
		return Math.sqrt(real*real+imag*imag);
}
}
