public class HexStringConverter{
	public static String[] hexStrings = {"2ae43", "8g023", "249abc", "2354aer23", "234245"};
    
    public static void main (String [] args)
    {	
    	char[] vc= {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
    	for(int a =0; a<vc.length; a++){System.out.print(vc[a]+", ");}
    	System.out.println();
    	
    	
    	char[] hexCharArray = hexStrings[0].toCharArray();
    	for(int i = 0 ; i < hexStrings.length; i++){
    		boolean flag = false;
    		for(int x=0; x<hexStrings[i].toCharArray().length; x++){
    			 flag = false;
    			for(int y=0; y<vc.length;y++){
		    		if(hexStrings[i].toCharArray()[x]==vc[y]){
		    			flag = true;
		    			
		    			}
		    		}
    		if(!flag){
    			System.out.println("The String "+hexStrings[i] +" is no valid hex-String");
    			break;
    			}
    			
    		
    	}
    	if(flag)
        {	int value = 0;
        	int figure = 0;
        	for(int j = hexStrings[i].toCharArray().length-1;j>=0;j--){
        		for(int z =0;z<vc.length;z++){
        			if (hexStrings[i].toCharArray()[j]==vc[z]){
	        		value=value+z* (int) Math.pow(16,figure);
	        		figure++;}
	        		}
        	}
        System.out.println("the decimal value of the hex-string "+hexStrings[i]+" is: "+value);
		}
    		}
    	
		
	}
}
