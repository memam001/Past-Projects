public class PasswordGenerator
{
	public static String validSymbols = "abcdefghijklmnopqrstuvwxyz1234567890():§$ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		public static char[] validChars = validSymbols.toCharArray();
		public static String newPassword = "";
		
	public static String generateNewPassword(char[] validChars){
				for(int i = 0; i < 8; i++)
		{
			newPassword = newPassword + validChars[(int)(Math.random()*validChars.length)];
			
		}return newPassword;
	}
	public static void main(String[] args)
	{
		generateNewPassword(validChars);
		
		System.out.println(newPassword);
	}
}
