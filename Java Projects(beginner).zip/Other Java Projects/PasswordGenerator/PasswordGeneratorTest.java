import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;
import Prog1Tools.GraphicScreen;

public class PasswordGeneratorTest
{
    private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();
    private static PipedOutputStream outputToConsole;
	private static PipedInputStream inputOfConsole;
	private static String outputString;
	public static boolean mainMethodRunSuccessuflly = false;
	
    @Before
    public void setUpTestCase()
    {	
    	try{
    		
			outputToConsole = new PipedOutputStream();
        	inputOfConsole  = new PipedInputStream(outputToConsole);
			System.setIn(inputOfConsole);
			System.setOut(new PrintStream(fromConsole));
			
	        String[] a = {""};
	        PasswordGenerator.main(a);
			outputString = fromConsole.toString();

			System.setOut(System.out);
    		System.setIn(System.in);
    		mainMethodRunSuccessuflly = true;
    	}catch(Exception e){System.err.println("Could not setup Streams");}
    }

    @After
    public void tearDownTestCase ()
    {
    	System.setOut(System.out);
    	System.setIn(System.in);
    }

    @Test
    public void InputOutputTest ()
    {	
        assertTrue("Main Method did non run succesfully",mainMethodRunSuccessuflly);
    }

    @Test
    public void runGeneratePasswordMethod(){
    	String validSymbols = "abcdefghijklmnopqrstuvwxyz1234567890():ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    	String returnedString1 = "";
    	String returnedString2 = "";
    	try{
			returnedString1 = PasswordGenerator.generateNewPassword(validSymbols.toCharArray());
			returnedString2 = PasswordGenerator.generateNewPassword(validSymbols.toCharArray());
    	}catch(Exception e){
    		throw new AssertionError("Failed to find or execute the public static method 'generateNewPassword(char[] a)' in class PasswordGenerator" );
    	}

		assertTrue("Generated Password not valid!", (returnedString1.length()>7));
		assertTrue("Generated Password not valid!", (returnedString2.length()>7));
		assertTrue("generatePassword does not generate random passwords", !(returnedString1.equals(returnedString2)));
    }   
}
