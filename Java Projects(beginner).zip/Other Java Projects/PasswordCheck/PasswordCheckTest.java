import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class PasswordCheckTest
{
    private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();
    private static PipedOutputStream outputToConsole;
	private static PipedInputStream inputOfConsole;
	private static String outputString;
	public static boolean mainMethodRunSuccessuflly = false;
	public static boolean firstPasswordtestsucceeded = false;
	public static boolean secondPasswordtestsucceeded = false;
	public static boolean thirdPasswordtestsucceeded = false;

    @Test
    public void runPasswordWithPlus(){
    	PasswordCheck.passwordInput = "abc+dce1".toCharArray();
    	assertFalse("password with + was accepted",PasswordCheck.passwordCorrect());
    }   

    @Test
    public void runPasswordWithFourLetter(){
    	PasswordCheck.passwordInput = "abc2".toCharArray();
    	assertFalse("Too short password was accepted",PasswordCheck.passwordCorrect());
    }  

    @Test
    public void runPasswordWithoutNumber(){
    	PasswordCheck.passwordInput = "abcdefg".toCharArray();
    	assertFalse("Password without number was accepted",PasswordCheck.passwordCorrect());
    }

    @Test
    public void runCorrectPassword(){
    	PasswordCheck.passwordInput = "abcdefg12".toCharArray();
    	assertTrue("correct Password 'abcdefg12' was not accepted",PasswordCheck.passwordCorrect());
    }
}


