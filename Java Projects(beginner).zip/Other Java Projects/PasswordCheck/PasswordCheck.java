import Prog1Tools.IOTools;
/* *
* Template for the password check exercise 
*
* @author Nils Schmidgruber & Matthes Elstermann
* @version 2014-Nov-19
*/
public class PasswordCheck
{
    static char[] passwordInput;
    private static char plus = '+';
    private static char minus = '-';
    
    public static void main (String [] args)
    {
        //Do the following tasks step by step
        
		//1. call the readPassword()-method and print the read password to the console

		//2. call the passwordCorrect()-method. If the the method returns 'false' print out an error message
		// NOTE: the passwordCorrect()-method is incomplete. By default it will only return 'false'

		//3. Go to the passwordCorrect()-method and add functionality
		readPassword();
		for(int i = 0; i<passwordInput.length;i++){
			System.out.print(passwordInput[i]);
		}
		System.out.println();
		
		
		//7. Write a loop that will force the user to input a 
		//   password as long as it is incorrect.
		  while(!passwordCorrect()){
		  	System.out.println("Not a valid password");
		  	readPassword();
		  }

        
    }

    //method that returns true if the password in the passwordInput-array is valid
    // (contains at least one digit but neither '+' nor '-'
    public static boolean passwordCorrect()
    {
    	boolean result = false;

		// Implement the following instructions step by step
		
    	// 4.) - Password must have at least 6 characters

        // 5.)- password is correct if it contains at least 1 number
        
        // 6.)- does not contain the characters  '+' and  '-'
        
        //  You should use the methods containsPlusMinus() and isADigit(char inputChar)
        //  that are implemented below
        //  You can of course define your own methods if you want to.
       
		if(passwordInput.length >= 6 && containsDigit() && !containsPlusMinus()){
			result= true;
		}
		return result;
        
    }

    //reads a String from the console and save it as a char-Array in the gloabl 'passwordInput'-Array
    public static void readPassword()
    {
        passwordInput = IOTools.readString("Please enter your new password: ").toCharArray();
    }

    //returns true if the global passwordInput-Array contains the char '+' or '-'
    public static boolean containsPlusMinus()
    {
        boolean result = false;
        for(int i=0; i<passwordInput.length && !result; i++)
        {
            if(passwordInput[i] == plus){result = true;}
            if(passwordInput[i] == minus){result = true;}
        }
        return result;
    }

    //returns true if the input char-value is a number char
    public static boolean isADigit(char inputChar)
    {
        boolean result = false;
        if(Character.isDigit(inputChar) == true){ result = true; }
        return result;
    }

	//This method is not implemented yet!!!!!!!!!!!!!!!!
	//If you want to you can implement it to check whether the global passwordInput-Array
	// contains a digit or not.
    public static boolean containsDigit(){
    	boolean result = false;
		for(int i=0; i<passwordInput.length;i++){
			if(isADigit(passwordInput[i])){
				result = true; 
			}
		}
    	
    	return result;
    }
}
