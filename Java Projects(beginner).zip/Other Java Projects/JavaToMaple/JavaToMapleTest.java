import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;
import java.io.File;

public class JavaToMapleTest
{
	private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();
    private static PipedOutputStream outputToConsole;
	private static PipedInputStream inputOfConsole;
	private static String outputString;
	
	@Test
	public void runMainMethod(){
		try{
			outputToConsole = new PipedOutputStream();
        	inputOfConsole  = new PipedInputStream(outputToConsole);
			System.setIn(inputOfConsole);
			System.setOut(new PrintStream(fromConsole));
			
			String[] a = {"50","0.05","30"};
			JavaToMaple.main(a);

			outputString = fromConsole.toString();
			System.setOut(System.out);
    		System.setIn(System.in);

    		//System.err.println(outputString);

			String errorMessage = "Output does not seem to be sufficently long enough to contain path data";
    		assertTrue(errorMessage,(outputString.length()>1000));
    		
			boolean printedOutSomething = true;
			
		}catch(Exception e){
    		throw new AssertionError("There was some error executing the main method ");
		}
	}
	
	@Test
	public void runPrintToConsole(){
		try{
			outputToConsole = new PipedOutputStream();
        	inputOfConsole  = new PipedInputStream(outputToConsole);
			System.setIn(inputOfConsole);
			System.setOut(new PrintStream(fromConsole));
			
	        JavaToMaple.printToConsole();
	       	//String[] a = {"50","0.05","30"};
			//JavaToMaple.main(a);
			outputString = fromConsole.toString();
			boolean printedOutSomething = true;

			String zeroOutput = "0.0, 0.0, 0.0";
			String errorMessage = "print console command did not seem to work. Expected to find: 150 x 0.0, 0.0, 0.0 ";
			printedOutSomething = outputString.contains(zeroOutput);
			assertTrue(errorMessage,printedOutSomething);
			
			System.setOut(System.out);
    		System.setIn(System.in);
    	}catch(Exception e){
    		throw new AssertionError("could not find or execute method; " +
							"printToConsole(...);");
		}
	}
}
