import java.io.FileWriter;
import java.io.IOException;


public class JavaToMaple{

	
	public static double t []  = new double[150]; 
	public static double x []  = new double[150]; 
	public static double y []  = new double[150]; 

	
	public static double V0;
	public static double deltaT;
	public static double launchAngle;
	




	
	public static void printToConsole(){
		
		for(int i=0;i<150;i++){
			System.out.println(t[i] + ", " + x[i] + ", " + y[i]);
		}

		
	}
	
	
	 
	public static void calc(){
		
		
		final double G = 9.81;
		double time = 0;
		for(int i=0;i<150;i++){
			t[i] = Math.rint(time*100)/100;
			x[i] = Math.rint((V0*time*Math.cos(launchAngle/180*Math.PI))*100)/100;
			y[i] = Math.rint((V0*time*Math.sin(launchAngle/180*Math.PI)-0.5*G*time*time)*100)/100;
	
			time = time + deltaT;
		}
			
	}
		
	public static double[] validParamCalc(){
		double[] result = new double[3];
		double velocity = 0;
		double timeDifference = 0;
		double initialAngle = 0;
		final double G = 9.81;
		double time = 0;

		for(velocity = 0; velocity<100; velocity=velocity+5){
			for(timeDifference=0; timeDifference<0.5; timeDifference = timeDifference + 0.02){
				for(initialAngle=0;initialAngle<90;initialAngle=initialAngle+3){
					for(int i=0;i<150;i++){
						t[i] = Math.rint(time*100)/100;
						x[i] = Math.rint((V0*time*Math.cos(initialAngle/180*Math.PI))*100)/100;
						y[i] = Math.rint((V0*time*Math.sin(initialAngle/180*Math.PI)-0.5*G*time*time)*100)/100;
			
						if(y[i]>0 && x[i]>100){
							result[0] = velocity;
							result[1] = timeDifference;
							result[2] = initialAngle;

							i=150;
							initialAngle=90;
							timeDifference=0.5;
							velocity=100;
						}
			
						time = time + timeDifference;
					}
				}
			}
		}

		return result;
	}
	
	public static void main(String[] args){

		
		V0 = Double.parseDouble(args[0]);
		deltaT = Double.parseDouble(args[1]);
		launchAngle = Double.parseDouble(args[2]);
		
		
		calc();
		printToConsole();

		
		

		
	}

	
	public static void saveMaple(String title){
		
		String plot = "restart; with(plots):A:=<<";

	
		try{
			
		    FileWriter w = new FileWriter(title + ".mw");

			int i = 0;
		    for(i = 0; i < t.length-1; i++){ plot = plot +  x[i] + ",";}
			plot = plot + x[i]+">|<";

			for(i = 0; i < t.length-1; i++){ plot = plot + y[i] + ",";}
			
			plot = plot + y[i]+">>:";
			plot = plot + "pointplot(A,color=blue,symbol=cross,labels=[distance,hight]);";
			
			w.append(plot);	 
		    w.flush();
		    w.close();	   
		    
		    System.out.println("\nFile saved as " + title);  
		    
		}catch(IOException e){e.printStackTrace();} 
	}
}
