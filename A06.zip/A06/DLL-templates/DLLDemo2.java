/**
 * Demo for a DoubleLinkedList from the according Excercise
 *
 * @version 2018-01-19
 * @author matthes.elstermann@kit.edu
 */
public class DLLDemo2
{
    public static void main (String [] args)
    {
        DoublyLinkedList liste = null;
        String sA = "Bela";
        String sB = "Farin";
        String sC = "Rod";
        
        liste = new DoublyLinkedList();
        System.out.println(liste);
        
        liste.insertLast(sA);
        System.out.println(liste);
        liste.insertLast(sB);
        System.out.println(liste);
        liste.insertLast(sC);
        System.out.println(liste);
        
        liste.insertFirst(sC);
        System.out.println(liste);
        liste.insertFirst(sB);
        System.out.println(liste);
        liste.insertFirst(sA);
        System.out.println(liste);
        
        liste.remove(sC);
        System.out.println(liste);
        liste.remove(sC);
        System.out.println(liste);
        liste.remove(sB);
        System.out.println(liste);
        liste.remove(sB);
        System.out.println(liste);
        liste.remove(sA);
        System.out.println(liste);
        liste.remove(sA);
        System.out.println(liste);
    }
}
