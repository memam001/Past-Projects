import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class DLLElementTest
{	
	@Test 
	public void createNewDLLElementInstances(){
		String newDataElement = "Demo" + ((Math.random()*100));
		DLLElement myListElement = new DLLElement();
				   myListElement.setObject(newDataElement);
		assertTrue ("Created new DLLElement and .setObject() with a new Object. " +
					"called .getObject() to retrive Data object but did not get it.",
				 newDataElement == myListElement.getObject());
		
	}
 
	
	

	@Test 
	public void testSetAndGetNextElement(){
		String newDataElement1 = "Demo" + ((Math.random()*100));
		DLLElement myListElement1 = new DLLElement();
				   myListElement1.setObject(newDataElement1);

		String newDataElement2 = "Demo" + ((Math.random()*100));
		DLLElement myListElement2 = new DLLElement();
				   myListElement2.setObject(newDataElement2);

		myListElement1.setNext(myListElement2);
		myListElement2.setPrevious(myListElement1);

		assertTrue("created two List Elements and tried to .setNext(). " +
				   "Did not get the set element with .getNext())",
					myListElement1.getNext() == myListElement2);
					
		assertTrue("created two List Elements and tried to .setPrevious(). " +
				   "Did not get the set element with .getPrevious())",
					myListElement2.getPrevious() == myListElement1);
	}
	
}
