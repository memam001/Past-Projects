import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class DLLTest
{	
	@Test 
	public void createNewDLListTest(){
		DoublyLinkedList liste = null;
        
        liste = new DoublyLinkedList();
	}

	@Test 
	public void insertOneAndToStringTest(){
		DoublyLinkedList liste = null;
        
        liste = new DoublyLinkedList();

		int randomNumber = (int)(Math.random()*100);
        String newDataElement1 = "Element" + (randomNumber);

        liste.insertFirst(newDataElement1);

        String output = liste.toString();

        assertTrue("created new list and .insertFirst() one new data element. " +
                   " called .toString() but Output did not contain new data element",
                   output.contains(newDataElement1));
	}

	@Test 
	public void insertLastAndToStringTest(){
		DoublyLinkedList liste = null;
        
        liste = new DoublyLinkedList();

		int randomNumber = (int)(Math.random()*100);
        String newDataElement1 = "Element" + (randomNumber);

        liste.insertLast(newDataElement1);

        String output = liste.toString();

        assertTrue("created new list and .insertLast() one new data element. " +
                   " called .toString() but Output did not contain new data element",
                   output.contains(newDataElement1));
	}


	@Test 
	public void dllListOrderTest(){
		DoublyLinkedList liste = null;
        
        liste = new DoublyLinkedList();

		int randomNumber = (int)(Math.random()*100);
        String newDataElement1 = "Element" + (randomNumber);
        String newDataElement2 = "Element" + (randomNumber+randomNumber);
        String newDataElement3 = "Element" + (randomNumber+randomNumber+randomNumber);

        liste.insertFirst(newDataElement1);
        liste.insertLast(newDataElement2);
        liste.insertFirst(newDataElement3);

        String output = liste.toString();

		String errorMessage = "created new list and inserted new data elements. " + System.lineSeparator() +
                   " expected .toString() order: " + 
                   newDataElement3 + " " + newDataElement1 + " " +newDataElement2 + System.lineSeparator() +
                   " but was: " + output;

        int posElement1 = output.indexOf(newDataElement1);
        int posElement2 = output.indexOf(newDataElement2);
        int posElement3 = output.indexOf(newDataElement3);        
                   
        assertTrue(errorMessage,  posElement3<posElement1 && posElement1 < posElement2);
	}    
}
