/**
 * Demo for a DoubleLinkedList from the according Excercise
 *
 * @version 2018-01-19
 * @author matthes.elstermann@kit.edu
 */
public class DLLDemo1
{
    public static void main (String [] args)
    {
        DoublyLinkedList liste = null;
        
        liste = new DoublyLinkedList();
        System.out.println(liste);
        
        liste.insertLast(1);
        System.out.println(liste);
        liste.insertLast(2);
        System.out.println(liste);
        liste.insertLast(3);
        System.out.println(liste);
        
        liste.insertFirst(3);
        System.out.println(liste);
        liste.insertFirst(2);
        System.out.println(liste);
        liste.insertFirst(1);
        System.out.println(liste);
        
        liste.remove(3);
        System.out.println(liste);
        liste.remove(3);
        System.out.println(liste);
        liste.remove(2);
        System.out.println(liste);
        liste.remove(2);
        System.out.println(liste);
        liste.remove(1);
        System.out.println(liste);
        liste.remove(1);
        System.out.println(liste);
    }
}
