import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class StringTreeTest
{	
	private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();

	@Test 
	public void createNewStringTreeInstances(){
		String randomString = "" +
			(char)((Math.random()*25)+97)+
			(char)((Math.random()*25)+97)+
			(char)((Math.random()*25)+97);
		StringTree myRoot = new StringTree(randomString);
	}

	@Test
	public void testInsertAndToString(){
		StringTree myRoot = new StringTree("M");
		myRoot.insert("A");
		myRoot.insert("Z");
		myRoot.insert("C");
		myRoot.insert("B");

		String toStringOutput = myRoot.toString();

		int posA,posB,posC,posM,posZ;
			posA = toStringOutput.indexOf("A");
			posB = toStringOutput.indexOf("B");
			posC = toStringOutput.indexOf("C");
			posM = toStringOutput.indexOf("M");
			posZ = toStringOutput.indexOf("Z");

		boolean allInOrder = posA<posB && posB<posC && posC<posM & posM<posZ;
		
		assertTrue("created StringTree with root M and inserted A,Z,C,and B." +
				   "expected output of toString() to have A, B, C, M, Z in that order ",
				   allInOrder);	
	}
}
