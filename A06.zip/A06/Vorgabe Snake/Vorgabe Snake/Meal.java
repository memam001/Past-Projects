//Template
import Prog1Tools.Screen;

class Meal {
	private static char mealChar = '#';
	private int positionX;
	private int positionY;

	public Meal() {
 
	}

	public Meal(int x, int y, char c) {
		positionX = x;
		positionY = y;
		mealChar = c;
	}

	int getPositionX() {
		return positionX;
	}

	int getPositionY() {
		return positionY;
	}

	public void setPosition(int x, int y) {
		positionX = x;
		positionY = y;
	}

	public static void setMealChar(char c) {
		mealChar = c;
	}

	public static char getMealChar() {
		return mealChar;
	}

	public static Meal createNewMealNotIn(Snake snake) {
		//TODO: Create new coordinates that are not inside the current Snake
		int x=(int)Math.ceil(Math.random()*24);
		int y=(int)Math.ceil(Math.random()*39)*2;
		
		//Return the new meal
		if(snake.contains(x,y)){
			x=(int)Math.ceil(Math.random()*24);
			y=(int)Math.ceil(Math.random()*39)*2;
			createNewMealNotIn(snake);
		}
		Meal result = new Meal(x,y,mealChar);
		
		
		return result;
	}
}
