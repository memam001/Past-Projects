//template
import Prog1Tools.IOTools;
import Prog1Tools.TextScreen;
import Prog1Tools.Screen;

public class SnakeGame
{

	static TextScreen screen = TextScreen.getInstance();
		
	static int speed = 2;

	//key konfiguration for the game
	public static final char CHAR_OBEN = 'w';
	public static final char CHAR_UNTEN = 's';
	public static final char CHAR_LINKS = 'a';
	public static final char CHAR_RECHTS = 'd';
	
		
	static Snake snake;
	static Meal meal;
	
    public static void main (String [] args)
    {
	    start();
		snake = new Snake(10,20,'O');
        meal = Meal.createNewMealNotIn(snake);
    	
    	//the loop that runs while playing
    	//runs as long as the isAlive-Method returns true 
    	while (snake.isAlive()){
    		
    		if (snake.contains(meal)){
    			snake.insertSnakeElement();
    			meal = Meal.createNewMealNotIn(snake);
    		}
			
			char direction = getDirection();
			snake.move(direction);
			refreshScreen();
			Screen.pause(speed*25); //the refres
		}
		
		end();
    }

    //Auxiluary method to initialize the TextScreen.
    private static void start(){
    	screen.setTitle("Snake");
        speed = screen.readInt("Schwierigkeitsstufe eingeben ","1 = sehr schwierig .... 6 = sehr einfach");
		screen.write(4,4,"Die Schlange wird mit den Tasten");
		screen.write(3,45, CHAR_OBEN);
		screen.write(5,41," "  + CHAR_LINKS + "  " + CHAR_UNTEN + "  " + CHAR_RECHTS);
		screen.write(4,55,"gesteuert.");
		screen.write(10,4,"Um zu beginnen dr�cke eine dieser Tasten");
		
		while(getDirection() == 'n'){}
		screen.clearScreen();
    }

	// Display the final score
    private static void end(){
    	screen.write(8,27,"Dein Ergebnis:    " + snake.getLength());
    }


	//Method to read input from the keyboard and 
	//recode the data to the internal data format: r,o,u,l,n
	//There is no Pause key!
	//warning German Programmers at workd:
	//	o = oben = up 		u = unten = down
	public static char getDirection (){
		//get selected key char
		if (screen.getSelectedKeyChar()== CHAR_RECHTS){
			return 'r';
		}else if (screen.getSelectedKeyChar()== CHAR_OBEN){
			return 'o';
		}else if (screen.getSelectedKeyChar()== CHAR_UNTEN){
			return 'u';
		}else if (screen.getSelectedKeyChar()== CHAR_LINKS){
			return 'l';
		}else{
			return 'n';
		}
	}

	//Auxiluary Method to reprint the screen
	private static void refreshScreen(){
		//display snake and meal on screen
		//meals are printed directly
		//snakes need to have a print-method, that recursivly
		//prints all their elements to the refered screen.
		screen.write(meal.getPositionX(),meal.getPositionY(),meal.getMealChar());
		snake.displayOn(screen);
	}
    
}
