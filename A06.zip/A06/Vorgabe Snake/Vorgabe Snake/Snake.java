//template
import Prog1Tools.Screen;
import Prog1Tools.TextScreen;


public class Snake {
	char snakeChar = 'o';
	char currentDirection;
	int length = 0;
	SnakeElement head;
	SnakeElement tail;

	//Constructors
	public Snake() { this(10, 10, 'O');}

	
	public Snake(int xStart, int yStart, char snakeChar) {

	//TODO: Implement Constructor that setsup a new Snake
	//and Links it head with its tail 
		SnakeElement couch = new SnakeElement(xStart, yStart, snakeChar);
		head = couch;
		tail = new SnakeElement(xStart, yStart-1, ' ');
		head.setNext(tail); 
		tail.setPrev(head);
		length = 1;
	}

	public int getLength() { return this.length; }


	//If this snake has contains the "meal" it should return true
	public boolean contains(Meal meal) {
		return this.contains(meal.getPositionX(), meal.getPositionY());	
	}


	public boolean contains(int x, int y) {
		boolean found = false;

		//TODO: should return true if a point with coordinates 'x' and 'y'
		// are within the snake 
		//Idea: start at the head and recursivly see if any element
		//of the snake is currently at x and y
		//if the tail has been reached without finding a match
		// the method should return false

		SnakeElement currentelement = head;
		
		while(currentelement != null){
			if(x==currentelement.getPositionX()&&y==currentelement.getPositionY()){
				found=true;
				return found;
			}
			else{
			currentelement= currentelement.getNext();
			
		}
		
		}	
		return found;
	}

	public void displayOn(TextScreen screen) {
				
		screen.write(head.getPositionX(),head.getPositionY(), head.getElementChar());
				
		//TODO: display all SnakeElements on screen, not only the head.
		//idea: recursively cycle through all elements of a the snake
		// and screen.write() their character.
		SnakeElement currentelement = head;
		
		while(currentelement != tail){
			currentelement= currentelement.getNext();
			screen.write(currentelement.getPositionX(),currentelement.getPositionY(), currentelement.getElementChar());
		}


		
		
	}

	public void insertSnakeElement() {
		//TODO: insert a new SnakeElement between tail and 
		//the previous SnakeElement of tail
		SnakeElement s = new SnakeElement(tail.getPositionX(),tail.getPositionY(), 'O');
		SnakeElement x = tail.getPrev();
		s.setPrev(x);
		x.setNext(s);
		s.setNext(tail);
		tail.setPrev(s);
		length = length + 1;
		
		
		
	}
	
		
	public void move(char dir) {
		//SnakeElements take the position of the previous Element
		currentDirection = dir;
		//TODO: Make all Elements of the Snake Move. 
		//Not only the head:

		SnakeElement currentelement = tail;
		//move head to selected direction 
		////warning German Programmers at workd coding is:
		//	o = oben = up 		u = unten = down (r = right, l = left)
		// down = positonX + 1, up positionX -1,
		// r = positionY + 1, l = positionY - 1,
		while(currentelement != head){
			currentelement.takePositionFromPrevious();
			currentelement= currentelement.getPrev();
		}
		if (currentDirection == 'u'){
			head.setPosition(head.getPositionX()+1,head.getPositionY());
		}
		else if (currentDirection == 'o'){
			head.setPosition(head.getPositionX()-1,head.getPositionY());
		}
		else if (currentDirection == 'r'){
			head.setPosition(head.getPositionX(),head.getPositionY()+2);
		}
		else if (currentDirection == 'l'){
			head.setPosition(head.getPositionX(),head.getPositionY()-2);
		}
		System.out.println(tail.getPositionX()+"-"+tail.getPositionY());
		
	}

	public boolean isAlive() {

		//TODO: Delete this when implementing
		int x = head.getPositionX();
		int y = head.getPositionY();
		//TODO: if head is touching the bounds the game is over
		if(x>24||x<0){
			return false;
		}
		else if(y>79||y<0){
			return false;
		}
		
		
		
		
		//TODO:if head has the same position than any SnakeElement the game is over
		SnakeElement currentelement = head.getNext();
		while(currentelement != null){
			if(x==currentelement.getPositionX()&&y==currentelement.getPositionY()){
				return false;
			}
			
			currentelement= currentelement.getNext();
			
		}
		
		return true;
		
		
		
	}
}
