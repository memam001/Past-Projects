//Template
public class SnakeElement{
	
    private char elementChar;
	private int positionX;
	private int positionY;
	
	private SnakeElement next;
	private SnakeElement previous;

	//Constructors
	public SnakeElement(){}
	
	public SnakeElement(int x,int y, char c){
		positionX = x;
		positionY = y;
		elementChar = c;
	}

	//getter + setter Methods for the Attributes
	int getPositionX(){ return positionX;}
	int getPositionY(){ return positionY;}
	
	void setPosition(int x, int y){
		positionX = x;
		positionY = y;
	}
	char getElementChar(){ return this.elementChar;}
	
	void setElementChar(char c){this.elementChar = c;}
	
	public void setNext(SnakeElement s){ next = s;}
	public void setPrev(SnakeElement s){ previous = s;}
	
	public SnakeElement getNext (){ return next;}
	public SnakeElement getPrev (){ return previous; }

	
	public void takePositionFromPrevious(){
		this.positionX = previous.getPositionX();
		this.positionY = previous.getPositionY();
	}
		
}
