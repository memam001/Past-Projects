import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class JumpingBallProceduralTest
{	
	@Test
	public void testRowChange(){
		assertTrue("call of rowChange(3,true) should return 4", 
					(JumpingBallProcedural.rowChange(3, true)==4));
		assertTrue("call of rowChange(3,false) should return 2", 
					(JumpingBallProcedural.rowChange(3, false)==2));
	}

	@Test
	public void testColumnChange(){
		assertTrue("call of columnChange(3,true) should return 4", 
					(JumpingBallProcedural.columnChange(3, true)==4));
		assertTrue("call of columnChange(3,false) should return 2", 
					(JumpingBallProcedural.columnChange(3, false)==2));
	}
	
	@Test
	public void testDirectionRow(){
		assertTrue("call of directionRow(3,true) should return true", 
					(JumpingBallProcedural.directionRow(3, true)==true));
		assertTrue("call of directionRow(3,false) should return false", 
					(JumpingBallProcedural.directionRow(3, false)==false));
					
		assertTrue("call of directionRow(0,false) should return true", 
					(JumpingBallProcedural.directionRow(0, false)==true));
		assertTrue("call of directionRow(0,true) should return true", 
					(JumpingBallProcedural.directionRow(0, true)==true));
			
		assertTrue("call of directionRow(24,false) should return false", 
					(JumpingBallProcedural.directionRow(24, false)==false));
		assertTrue("call of directionRow(24,true) should return false", 
					(JumpingBallProcedural.directionRow(24, true)==false));	
	}

	@Test
	public void testdirectionColumn(){
		assertTrue("call of directionColumn(3,true) should return true", 
					(JumpingBallProcedural.directionColumn(3, true)==true));
		assertTrue("call of directionColumn(3,false) should return false", 
					(JumpingBallProcedural.directionColumn(3, false)==false));
					
		assertTrue("call of directionColumn(0,false) should return true", 
					(JumpingBallProcedural.directionColumn(0, false)==true));
		assertTrue("call of directionColumn(0,true) should return true", 
					(JumpingBallProcedural.directionColumn(0, true)==true));
			
		assertTrue("call of directionColumn(79,false) should return false", 
					(JumpingBallProcedural.directionColumn(79, false)==false));
		assertTrue("call of directionColumn(79,true) should return false", 
					(JumpingBallProcedural.directionColumn(79, true)==false));	
	}
}
