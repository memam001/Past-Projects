import Prog1Tools.IOTools;

public class InverterRecursive{
	
	public static void main(String[] args){
		System.out.println("===============================");
		System.out.println("Inverter");
		System.out.println("===============================\n");
	
		String inverted = recursion(1);
		System.out.println("\nThe inverted order is: "+inverted);
	}

	public static String recursion(int counter){
		
		char input = IOTools.readChar(counter+".Character: ");
		
		if(input=='x' || input=='X'){
			return input+"";
		}
		else{ 
			return recursion(counter+1)+input;
		}
	}
}




