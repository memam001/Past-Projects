import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class InverterRecursiveTest
{
	public static char charA, charB, charC;
	
	private static final ByteArrayOutputStream fromConsole = new ByteArrayOutputStream();
    private static PipedOutputStream outputToConsole;
	private static PipedInputStream inputOfConsole;
	private static TestInputThreadRecursiv inputThread;
	public static boolean testPassed = true;
	
	@Test
	public void runMainMethod(){
		try{
			outputToConsole = new PipedOutputStream();
        	inputOfConsole  = new PipedInputStream(outputToConsole);
			System.setIn(inputOfConsole);
			System.setOut(new PrintStream(fromConsole));

			createRandomButDifferenChars();
			
			inputThread = new TestInputThreadRecursiv(outputToConsole);
			inputThread.start();

			
			String[] a = {""};
			InverterRecursive.main(a);

			String outputString  = fromConsole.toString();

			int posA, posB, posC, posX;

			posX = outputString.toLowerCase().lastIndexOf("x");

			posA = outputString.toLowerCase().indexOf(""+charA,posX);
			posB = outputString.toLowerCase().indexOf(""+charB,posX);
			posC = outputString.toLowerCase().indexOf(""+charC,posX);


			assertTrue("Inputted chars do not seem to be printed out in inverse order",
						(posA>posB && posB>posC));

			System.setOut(System.out);
    		System.setIn(System.in);
			
    	}catch(Exception e){System.err.println("Could not setup Streams");}
	}

	public static void createRandomButDifferenChars(){
		
		do{ charA =(char)((Math.random()*25)+97);}
		while(charA =='x'||charA =='X');

		do{ charB =(char)((Math.random()*25)+97);}
		while(charB==charA || charB =='x'||charA =='X');

		do{ charC =(char)((Math.random()*25)+97);}
		while(charC==charA ||charC==charB || charC =='x'||charA =='X');
	}
}

/**
 * This Thread runs in parallel to the expected main method
 * It simulates console input from a human being
 * the streams should have been send.
 */
class TestInputThreadRecursiv extends Thread{
	PipedOutputStream byteStreamToConsole;
	
	public TestInputThreadRecursiv(PipedOutputStream byteStreamToConsole){
		this.byteStreamToConsole = byteStreamToConsole;
	}

	public void run()
  	{	
  		try 
      	{	
        	sleep(1);
        	byteStreamToConsole.write((""+InverterRecursiveTest.charA).getBytes());
        	byteStreamToConsole.write(System.lineSeparator().getBytes());

        	sleep(1);
        	byteStreamToConsole.write((""+InverterRecursiveTest.charB).getBytes());
        	byteStreamToConsole.write(System.lineSeparator().getBytes());

        	sleep(1);
        	byteStreamToConsole.write((""+InverterRecursiveTest.charC).getBytes());
        	byteStreamToConsole.write(System.lineSeparator().getBytes());


        	sleep(1);
        	byteStreamToConsole.write("x".getBytes());
        	byteStreamToConsole.write(System.lineSeparator().getBytes());
        	
        	
        } 
      	catch (Exception e) {
      		System.err.println("Error in InputThread");
      		InverterRecursiveTest.testPassed = false;
      	} 
  	}
}
