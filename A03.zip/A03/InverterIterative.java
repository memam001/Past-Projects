import Prog1Tools.IOTools;

public class InverterIterative {
	public static char[] saved_input = new char[100];
	public static int valueofi;
	public static void main(String[] args)
	{

		System.out.println("===============================");
		System.out.println("Inverter");
		System.out.println("===============================\n");
		int i = 0;
		saved_input[i] = IOTools.readChar((i+1) +".Character: ");
		while(saved_input[i] != 'X' && saved_input[i] != 'x' && i<saved_input.length-1)
		{
			i = i+1;
			saved_input[i] = IOTools.readChar((i+1) +".Character: ");
			valueofi = i;
		}

		
		String inverted_order = "";
		
		for(int j = valueofi; j>=0; j--)
		{
			
			inverted_order+=saved_input[j];
		}
		System.out.println("\nThe inverted order is: "+inverted_order);
	
	}
		
		

		
		
		
	
}

