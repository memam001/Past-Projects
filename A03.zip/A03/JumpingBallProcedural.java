import Prog1Tools.Screen;
import Prog1Tools.TextScreen;

public class JumpingBallProcedural
{
   
    
    static final String BALL = "O";
    static final String BALL1 = "O";
    
    static final int PAUSE_TIME = 100;
    static final int MAX_ROW = 24;
    static final int MAX_COLUMN = 79;
    
    public static int numberOfStepsToTake = 175;
    public static int step = 0;
    
    
    public static int row = 0;
    public static int row1 = 24;
    public static int column = 0;
    public static int column1 = 0;
    public static boolean rowDescending = true;
    public static boolean rowDescending1 = true;
    public static boolean columnDescending = true;
    public static boolean columnDescending1 = true;

 public static void main (String[] args)
    {	
    	TextScreen screen = TextScreen.getInstance();
    	 
        screen.setTitle("Jumping Balls Procedural");
        
        for(step=1; step<=numberOfStepsToTake; step =step+1)
        {screen.clearScreen();
           //Checking for direction change
           rowDescending = directionRow(row, rowDescending);
           columnDescending = directionColumn(column, columnDescending);
           //updating row and column
           row = rowChange(row,rowDescending);
           column = columnChange(column, columnDescending);

           rowDescending1 = directionRow(row1, rowDescending1);
           columnDescending1 = directionColumn(column1, columnDescending1);
           //updating row and column
           row1 = rowChange(row1,rowDescending1);
           column1 = columnChange(column1, columnDescending1);
           //printing the current position
           screen.write(row, column, BALL);
           screen.write(row1, column1, BALL1);

           //pausing the screen for humans
           Screen.pause(PAUSE_TIME);
        }
    }

       

	//C:
    //method that will calculate and return the new row
    //depending on the current direction of a ball
    public static int rowChange(int row, boolean descending)
    {
    	
    	if(descending){
    		return row+1;
    	}

    	else{
    		return row-1;
    	}
    }

    //D:
    //method that will calculate and return the new column
    //depending on the current direction of a ball
    public static int columnChange(int column, boolean descending)
    {
   
    	if(descending){return column+1;}
    	else{return column-1;}
        //TODO: impelment method functionality
        
    }

	//E:
    //method that will return a new vertical (row) direction 
    //if the maximum or minimum row (0 - 24) has been reached
    //will return the original value if no extrem has been reeched
    public static boolean directionRow(int row, boolean currentDirection)
    {
        if(row==MAX_ROW){return false;} 
       else if(row==0){return true;}
		else{return currentDirection;}
        
    }

	//F:
    //method that will return a new vertical (row) direction 
    //if the maximum or minimum column (0 - 79) has been reached
    //will return the original value if no extrem has been reeched
    public static boolean directionColumn(int column, boolean currentDirection)
    {
       if(column==MAX_COLUMN){return false;}
       else if(column==0){return true;}
		else{return currentDirection;} //TODO: impelment method functionality

        
    }
}
